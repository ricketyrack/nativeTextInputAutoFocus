//>>built
define("dijit/nls/fr/loading",({loadingState:"Chargement...",errorState:"Une erreur est survenue"}));
