//>>built
define("dijit/nls/tr/loading",({loadingState:"Yükleniyor...",errorState:"Üzgünüz, bir hata oluştu"}));
